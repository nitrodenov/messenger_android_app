package ru.nitrodenov.messenger.module.channels.entity

import android.graphics.Bitmap
import ru.nitrodenov.messenger.TaskResult

class Logos(var logos: List<Bitmap>?) : TaskResult() {
}