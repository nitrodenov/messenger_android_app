package ru.nitrodenov.messenger

open class TaskResult {
}