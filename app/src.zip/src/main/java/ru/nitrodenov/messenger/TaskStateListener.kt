package ru.nitrodenov.messenger

interface TaskStateListener {

    fun onPreExecute()

    fun onCancelled()

    fun onPostExecute()

}