package ru.nitrodenov.messenger

import android.graphics.Bitmap
import android.util.LruCache

interface ImageCache {

    fun getBitmapFromDiskCache(id: String): Bitmap?

    fun addBitmapToCache(id: String, bitmap: Bitmap)

    fun getBitmapFromMemoryCache(id: String): Bitmap?

}

class ImageCacheImpl(private val inMemoryCache: LruCache<String, Bitmap>) : ImageCache {

    override fun getBitmapFromDiskCache(id: String): Bitmap? {
        return null
    }

    override fun addBitmapToCache(id: String, bitmap: Bitmap) {
        inMemoryCache.put(id, bitmap)
    }

    override fun getBitmapFromMemoryCache(id: String): Bitmap? {
        return inMemoryCache.get(id)
    }

}