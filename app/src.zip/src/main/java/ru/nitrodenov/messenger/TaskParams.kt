package ru.nitrodenov.messenger

class TaskParams {
}