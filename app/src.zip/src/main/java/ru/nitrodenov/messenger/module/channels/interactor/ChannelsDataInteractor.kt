package ru.nitrodenov.messenger.module.channels.interactor

import android.util.Log
import ru.nitrodenov.messenger.async.AsyncHandler
import ru.nitrodenov.messenger.PendingTask
import ru.nitrodenov.messenger.TaskParams
import ru.nitrodenov.messenger.TaskResult
import ru.nitrodenov.messenger.module.channels.entity.ChannelsData
import ru.nitrodenov.messenger.module.channels.entity.createMock
import ru.nitrodenov.messenger.module.channels.view.ChannelsView
import java.lang.ref.WeakReference

interface ChannelsDataInteractor {

    fun loadChannelsData(id: String, callback: ChannelsView.ChannelsDataCallback)

    fun stopTask(id: String)

}

class ChannelsDataInteractorImpl(private val asyncHandler: AsyncHandler) : ChannelsDataInteractor {

    override fun loadChannelsData(id: String, callback: ChannelsView.ChannelsDataCallback) {
        val channelsDataTask = ChannelsDataTask(callback)
        asyncHandler.submit(id, channelsDataTask)
    }

    override fun stopTask(id: String) {
        asyncHandler.stopTask(id)
    }

}

class ChannelsDataTask(callback: ChannelsView.ChannelsDataCallback?) : PendingTask() {

    private val channelsDataCallback = WeakReference<ChannelsView.ChannelsDataCallback>(callback)

    override fun doInBackground(vararg params: TaskParams?): TaskResult {
        Log.d("ChannelsDataTask", this.toString())

        return createMock()
    }

    override fun onPostExecute(result: TaskResult?) {
        super.onPostExecute(result)

        val channelsData = result as ChannelsData

        val callback = channelsDataCallback.get()
        callback?.onChannelsDataLoaded(channelsData)
    }
}