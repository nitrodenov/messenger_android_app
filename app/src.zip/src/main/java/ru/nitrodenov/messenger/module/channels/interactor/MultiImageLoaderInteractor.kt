package ru.nitrodenov.messenger.module.channels.interactor

import android.util.Log
import android.widget.ImageView
import ru.nitrodenov.messenger.ImageCache
import ru.nitrodenov.messenger.ImageResultCallback
import ru.nitrodenov.messenger.async.AsyncHandler

interface MultiImageLoaderInteractor {

    fun loadImages(position: Int, imageView: ImageView, imageUrls: List<String>)

}

class MultiImageLoaderInteractorImpl(private val asyncHandler: AsyncHandler,
                                     private val imageCache: ImageCache) : MultiImageLoaderInteractor, ImageResultCallback {

    override fun loadImages(position: Int, imageView: ImageView, imageUrls: List<String>) {
        if (imageUrls.isEmpty()) {
            return
        }

        val noCachedImages = ArrayList<String>()

        for (url in imageUrls) {
            val image = imageCache.getBitmapFromMemoryCache(url)
            if (image != null) {
                imageView.setImageBitmap(image)
            } else {
                noCachedImages.add(url)
            }
        }

        if (noCachedImages.isNotEmpty() && cancelPotentialWork(noCachedImages.toString(), imageView)) {
            val task = MultiImageLoaderTask(imageView = imageView, imageCache = imageCache, urls = noCachedImages, resultCallback = this)
            asyncHandler.submit(imageView.hashCode().toString(), task)
        }

    }

    private fun cancelPotentialWork(url: String, imageView: ImageView): Boolean {
        Log.d("MultiImageInteractor", "try to cancelPotentialWork $url in ${imageView.hashCode()}")
        val task = asyncHandler.getTask(imageView.hashCode().toString()) as? MultiImageLoaderTask
        if (task != null) {
            val handlingTaskUrl = task.urls.toString()
            if (handlingTaskUrl != url) {
                // если пришел новый url, останавливаем загрузку картинки по старому url
                asyncHandler.stopTask(imageView.hashCode().toString())
            } else {
                // уже выполняется загрузка
                return false
            }
        }
        Log.d("MultiImageInteractor", "cancelPotentialWork $url in ${imageView.hashCode()}")
        return true
    }


    override fun onLoaded(taskId: String) {
        asyncHandler.removeTask(taskId)
    }

}