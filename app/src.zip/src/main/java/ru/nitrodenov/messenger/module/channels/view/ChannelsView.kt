package ru.nitrodenov.messenger.module.channels.view

import android.graphics.Bitmap
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.view.View
import ru.nitrodenov.messenger.R
import ru.nitrodenov.messenger.module.channels.entity.ChannelsData
import ru.nitrodenov.messenger.widgets.MultipleImageView

interface ChannelsView {

    fun showChannelsData(channelsData: ChannelsData)

    fun showScreenProgress()

    fun showScreenError()

    fun showChannelLogo(id: MultipleImageView, logo: Bitmap)

    fun showChannelLogoProgress()

    fun showChannelLogoError()

    interface LogoImageResultCallback {

        fun onLogoImageLoaded(id: MultipleImageView)

    }

    interface ChannelsDataCallback {

        fun onChannelsDataLoaded(channelsData: ChannelsData)

    }

    interface LogoImageCallback {

        fun loadLogo(position: Int, imageView: MultipleImageView, imageUrls: List<String>)

        fun onLogoImageLoaded(logo: Bitmap, imageView: MultipleImageView)

    }
}

class ChannelsViewImpl(view: View, logoCallback: ChannelsView.LogoImageCallback) : ChannelsView {

    private val recyclerView = view.findViewById<RecyclerView>(R.id.recycler_view)
    private val adapter: ChannelsAdapter = ChannelsAdapter(logoCallback)

    init {
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(recyclerView.context, LinearLayoutManager.VERTICAL, false)

        val toolbar = view.findViewById<Toolbar>(R.id.toolbar)
        toolbar.title = "Список бесед"
    }

    override fun showChannelsData(channelsData: ChannelsData) {
        adapter.channelsData = channelsData
        adapter.notifyDataSetChanged()
    }

    override fun showScreenProgress() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showScreenError() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showChannelLogo(id: MultipleImageView, logo: Bitmap) {
        adapter.showLogo(id, logo)
    }

    override fun showChannelLogoProgress() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showChannelLogoError() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}

private const val TAG = "ChannelsView"