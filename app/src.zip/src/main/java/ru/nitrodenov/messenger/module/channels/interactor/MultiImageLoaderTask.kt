package ru.nitrodenov.messenger.module.channels.interactor

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Log
import android.widget.ImageView
import ru.nitrodenov.messenger.ImageCache
import ru.nitrodenov.messenger.ImageResultCallback
import ru.nitrodenov.messenger.PendingTask
import ru.nitrodenov.messenger.TaskParams
import ru.nitrodenov.messenger.TaskResult
import ru.nitrodenov.messenger.module.channels.entity.Logos
import java.io.IOException
import java.lang.ref.WeakReference
import java.net.HttpURLConnection
import java.net.URL

class MultiImageLoaderTask(val urls: List<String>,
                           imageView: ImageView,
                           private val imageCache: ImageCache?,
                           private val resultCallback: ImageResultCallback) : PendingTask() {

    private val weakImageView = WeakReference<ImageView>(imageView)

    override fun doInBackground(vararg params: TaskParams?): TaskResult {
        val logos = ArrayList<Bitmap>()
        for (url in urls) {
            Log.d("ImageLoaderTask", "start loading $url in ${weakImageView.get()}")
            var bitmap: Bitmap? = null

            if (imageCache != null && !isCancelled && getAttachedImageView() != null) {
                bitmap = imageCache.getBitmapFromDiskCache(url)
            }

            if (bitmap == null && !isCancelled && getAttachedImageView() != null) {
                bitmap = downloadImage(url)
            }

            if (bitmap != null) {
                imageCache?.addBitmapToCache(url, bitmap)
                logos.add(bitmap)
            }
        }

        return Logos(logos)
    }

    override fun onPostExecute(result: TaskResult?) {
        super.onPostExecute(result)

        val imageView = getAttachedImageView()
        val logos = (result as? Logos)?.logos

        if (!isCancelled && logos != null && imageView != null) {
            for (logo in logos) {
                if (!isCancelled) {
                    Log.d("ImageLoaderTask", "add in ${weakImageView.get()}")
                    imageView.setImageBitmap(logo)
                }
            }
        }

        val taskId = getAttachedImageView()?.hashCode()?.toString()
        if (taskId != null) {
            resultCallback.onLoaded(taskId)
        }
    }

    override fun onCancelled() {
        super.onCancelled()
        val taskId = getAttachedImageView()?.hashCode()?.toString()
        if (taskId != null) {
            resultCallback.onLoaded(taskId)
        }
    }

    private fun getAttachedImageView(): ImageView? {
        return weakImageView.get()
    }

    private fun downloadImage(url: String): Bitmap? {
        try {
            val mUrl = URL(url)
            val httpConnection = mUrl.openConnection() as HttpURLConnection
            httpConnection.requestMethod = "GET"
            httpConnection.setRequestProperty("Content-length", "0")
            httpConnection.useCaches = false
            httpConnection.allowUserInteraction = false
            httpConnection.connectTimeout = 100000
            httpConnection.readTimeout = 100000

            httpConnection.connect()

            val responseCode = httpConnection.responseCode

            if (responseCode == HttpURLConnection.HTTP_OK && !isCancelled) {
                return BitmapFactory.decodeStream(httpConnection.inputStream)
            }
        } catch (e: IOException) {
            e.printStackTrace()
        } catch (ex: Exception) {
            ex.printStackTrace()
        }
        return null
    }
}