package ru.nitrodenov.messenger.module.channels.router

interface ChannelsRouter {
}