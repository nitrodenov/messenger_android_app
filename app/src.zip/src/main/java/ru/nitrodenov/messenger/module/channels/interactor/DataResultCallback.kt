package ru.nitrodenov.messenger.module.channels.interactor

import android.graphics.Bitmap

interface DataResultCallback {

    fun onComplete(logo: Bitmap?)

}