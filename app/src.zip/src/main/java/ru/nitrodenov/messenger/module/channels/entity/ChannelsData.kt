package ru.nitrodenov.messenger.module.channels.entity

import android.os.Parcel
import android.os.Parcelable
import ru.nitrodenov.messenger.TaskResult

class ChannelsData(val channels: List<ShortChannelData>) : TaskResult(), Parcelable {
    constructor(parcel: Parcel) : this(parcel.createTypedArrayList(ShortChannelData)) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeTypedList(channels)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<ChannelsData> {
        override fun createFromParcel(parcel: Parcel): ChannelsData {
            return ChannelsData(parcel)
        }

        override fun newArray(size: Int): Array<ChannelsData?> {
            return arrayOfNulls(size)
        }
    }

}

fun createMock(): ChannelsData {
    val channels = ArrayList<ShortChannelData>()

    for (i in 0..100) {
        val logos = listOf("https://avatars.yandex.net/get-music-content/42108/0ce84788.p.1053/m30x30", "https://avatars.yandex.net/get-music-content/28589/10820c62.p.3504/m30x30")
//        val logos = listOf("https://avatars.yandex.net/get-music-content/42108/0ce84788.p.1053/m30x30")
        val shortChannelData = ShortChannelData(title = "Бостонское чаепитие $i",
                time = "12:44",
                description = "dfgsfg $i",
                logos = logos)
        channels.add(shortChannelData)
    }

    return ChannelsData(channels)
}