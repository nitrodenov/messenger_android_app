package ru.nitrodenov.messenger.module.channel.interactor

import android.util.Log
import android.widget.ImageView
import ru.nitrodenov.messenger.ImageCache
import ru.nitrodenov.messenger.ImageResultCallback
import ru.nitrodenov.messenger.async.AsyncHandler

interface ImageLoaderInteractor {

    fun loadImage(imageView: ImageView, url: String?)

}

class ImageLoaderInteractorImpl(private val asyncHandler: AsyncHandler,
                                private val imageCache: ImageCache) : ImageLoaderInteractor, ImageResultCallback {

    override fun loadImage(imageView: ImageView, url: String?) {
        if (url == null || url.isEmpty()) {
            return
        }

        val image = imageCache.getBitmapFromMemoryCache(url)
        if (image != null) {
            imageView.setImageBitmap(image)
        } else if (cancelPotentialWork(url, imageView)) {
            val task = ImageLoaderTask(imageView = imageView, imageCache = imageCache, url = url, resultCallback = this)
            asyncHandler.submit(imageView.hashCode().toString(), task)
        }
    }

    private fun cancelPotentialWork(url: String, imageView: ImageView): Boolean {
        Log.d("ImageLoaderInteractor", "try to cancelPotentialWork $url in ${imageView.hashCode()}")
        val task = asyncHandler.getTask(imageView.hashCode().toString()) as? ImageLoaderTask
        if (task != null) {
            val handlingTaskUrl = task.url
            if (handlingTaskUrl != url) {
                // если пришел новый url, останавливаем загрузку картинки по старому url
                asyncHandler.stopTask(imageView.hashCode().toString())
            } else {
                // уже выполняется загрузка
                return false
            }
        }
        Log.d("ImageLoaderInteractor", "cancelPotentialWork $url in ${imageView.hashCode()}")
        return true
    }


    override fun onLoaded(taskId: String) {
        asyncHandler.removeTask(taskId)
    }

}