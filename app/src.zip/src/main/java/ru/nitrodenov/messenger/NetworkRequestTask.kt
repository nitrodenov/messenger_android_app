package ru.nitrodenov.messenger

class NetworkRequestTask : PendingTask() {

    override fun doInBackground(vararg params: TaskParams?): TaskResult {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }
}