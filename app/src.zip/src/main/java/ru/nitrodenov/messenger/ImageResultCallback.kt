package ru.nitrodenov.messenger

interface ImageResultCallback {

    fun onLoaded(taskId: String)

}