package ru.nitrodenov.messenger.module.channels

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import ru.nitrodenov.messenger.module.channels.router.ChannelsRouter

class ChannelsActivity : AppCompatActivity(), ChannelsRouter {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (savedInstanceState == null) {
            supportFragmentManager
                    .beginTransaction()
                    .add(android.R.id.content, ChannelsFragment())
                    .commit()
        }
    }
}
