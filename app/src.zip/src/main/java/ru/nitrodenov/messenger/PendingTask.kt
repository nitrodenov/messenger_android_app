package ru.nitrodenov.messenger

import android.os.AsyncTask

abstract class PendingTask : AsyncTask<TaskParams, TaskProgress, TaskResult>() {

    var taskStateListener : TaskStateListener? = null
}