package ru.nitrodenov.messenger.module.channels.presenter

import android.graphics.Bitmap
import android.os.Bundle
import ru.nitrodenov.messenger.module.channels.entity.ChannelsData
import ru.nitrodenov.messenger.module.channels.interactor.ChannelsDataInteractor
import ru.nitrodenov.messenger.module.channels.interactor.MultiImageLoaderInteractor
import ru.nitrodenov.messenger.module.channels.router.ChannelsRouter
import ru.nitrodenov.messenger.module.channels.view.ChannelsView
import ru.nitrodenov.messenger.widgets.MultipleImageView

interface ChannelsPresenter : ChannelsView.ChannelsDataCallback, ChannelsView.LogoImageCallback {

    fun attachView(view: ChannelsView)

    fun detachView()

    fun attachRouter(router: ChannelsRouter)

    fun detachRouter()

    fun getState(): Bundle

}

class ChannelsPresenterImpl(private val channelsDataInteractor: ChannelsDataInteractor,
                            private val multiImageLoaderInteractor: MultiImageLoaderInteractor,
                            state: Bundle?) : ChannelsPresenter {

    private var view: ChannelsView? = null
    private var router: ChannelsRouter? = null
    private var data: ChannelsData? = state?.getParcelable(KEY_STATE)

    override fun attachView(view: ChannelsView) {
        this.view = view

        showChannelsData()
    }


    override fun detachView() {
        this.view = null
        stopTask()
    }

    override fun attachRouter(router: ChannelsRouter) {
        this.router = router
    }

    override fun detachRouter() {
        this.router = null
    }

    override fun getState(): Bundle {
        val bundle = Bundle()
        bundle.putParcelable(KEY_STATE, data)
        return bundle
    }

    override fun onChannelsDataLoaded(channelsData: ChannelsData) {
        this.data = channelsData
        bindChannelsData(data)
    }

    override fun onLogoImageLoaded(logo: Bitmap, imageView: MultipleImageView) {
        view?.showChannelLogo(imageView, logo)
    }

    override fun loadLogo(position: Int, imageView: MultipleImageView, imageUrls: List<String>) {
        multiImageLoaderInteractor.loadImages(position, imageView, imageUrls)
    }

    private fun showChannelsData() {
        val data = this.data
        if (data == null) {
            loadChannelsData()
        } else {
            bindChannelsData(data)
        }
    }

    private fun loadChannelsData() {
        channelsDataInteractor.loadChannelsData("id", this)
    }

    private fun bindChannelsData(data: ChannelsData?) {
        if (data != null) {
            view?.showChannelsData(data)
        }
    }

    private fun stopTask() {
        channelsDataInteractor.stopTask("id")
    }
}

private const val KEY_STATE = "key_state"