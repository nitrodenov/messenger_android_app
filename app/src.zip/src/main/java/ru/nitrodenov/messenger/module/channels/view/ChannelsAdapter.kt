package ru.nitrodenov.messenger.module.channels.view

import android.graphics.Bitmap
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import ru.nitrodenov.messenger.R
import ru.nitrodenov.messenger.module.channels.entity.ChannelsData
import ru.nitrodenov.messenger.widgets.MultipleImageView

class ChannelsAdapter(private val logoCallback: ChannelsView.LogoImageCallback) :
        RecyclerView.Adapter<ChannelsViewHolder>(), ChannelsView.LogoImageResultCallback {

    var channelsData: ChannelsData? = null

    override fun onCreateViewHolder(parent: ViewGroup?, viewType: Int): ChannelsViewHolder {
        val view = LayoutInflater.from(parent?.context).inflate(R.layout.channels_item, parent, false)
        return ChannelsViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChannelsViewHolder?, position: Int) {
        holder?.titleTextView?.text = channelsData?.channels?.get(position)?.title
        holder?.descriptionTextView?.text = channelsData?.channels?.get(position)?.description
        holder?.timeTextView?.text = channelsData?.channels?.get(position)?.time

        holder?.logosMultiImageView?.setImageBitmap(null)
        logoCallback.loadLogo(position,
                holder?.logosMultiImageView!!,
                channelsData?.channels?.get(position)?.logos ?: ArrayList())
    }

    override fun getItemCount(): Int {
        return channelsData?.channels?.size ?: 0
    }

    fun showLogo(imageView: MultipleImageView, logo: Bitmap) {
        imageView.setImageBitmap(logo)
    }

    override fun onLogoImageLoaded(id: MultipleImageView) {

    }
}