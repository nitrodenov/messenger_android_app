package ru.nitrodenov.messenger.async

import ru.nitrodenov.messenger.PendingTask
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService

interface AsyncHandler {

    fun submit(id: String, task: PendingTask)

    fun stopTask(id: String)

    fun removeTask(id: String)

    fun stopAllTasks()

    fun removeIfExist(id: String)

    fun getTask(id: String): PendingTask?

    fun getTasksContains(id: String): Map<String, PendingTask>?

}

class AsyncHandlerImpl(private val executorService: ExecutorService) : AsyncHandler {

    private val tasks = ConcurrentHashMap<String, PendingTask>()

    override fun submit(id: String, task: PendingTask) {
        task.executeOnExecutor(executorService)
        tasks.put(id, task)
    }

    override fun stopTask(id: String) {
        val task = tasks[id]
        task?.cancel(true)
        tasks.remove(id)
    }

    override fun stopAllTasks() {
        tasks.forEach { it.value.cancel(true) }
        tasks.clear()
    }

    override fun removeTask(id: String) {
        tasks.remove(id)
    }

    override fun removeIfExist(id: String) {
        tasks.forEach {
            if (it.key.contains(id)) {
                it.value.cancel(true)
            }
        }
        tasks.filter { it.key != id }
    }

    override fun getTask(id: String): PendingTask? {
        return tasks[id]
    }

    override fun getTasksContains(id: String): Map<String, PendingTask>? {
        return tasks.filter { it.key.contains(id) }
    }
}