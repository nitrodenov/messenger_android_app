package ru.nitrodenov.messenger

class TaskProgress {
}