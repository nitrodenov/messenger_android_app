package ru.nitrodenov.messenger.di.module;

import android.os.Bundle;

import javax.annotation.Nullable;

import dagger.Module;
import dagger.Provides;
import ru.nitrodenov.messenger.ImageCache;
import ru.nitrodenov.messenger.async.AsyncHandler;
import ru.nitrodenov.messenger.di.scope.ChannelsScope;
import ru.nitrodenov.messenger.module.channels.interactor.ChannelsDataInteractor;
import ru.nitrodenov.messenger.module.channels.interactor.ChannelsDataInteractorImpl;
import ru.nitrodenov.messenger.module.channels.interactor.MultiImageLoaderInteractor;
import ru.nitrodenov.messenger.module.channels.interactor.MultiImageLoaderInteractorImpl;
import ru.nitrodenov.messenger.module.channels.presenter.ChannelsPresenter;
import ru.nitrodenov.messenger.module.channels.presenter.ChannelsPresenterImpl;

@Module
public class ChannelsModule {

    @Nullable
    private final Bundle state;

    public ChannelsModule(@Nullable Bundle state) {
        this.state = state;
    }

    @Provides
    @ChannelsScope
    ChannelsDataInteractor provideChannelsDataInteractor(AsyncHandler asyncHandler) {
        return new ChannelsDataInteractorImpl(asyncHandler);
    }

    @Provides
    @ChannelsScope
    MultiImageLoaderInteractor provideImageLoaderInteractor(AsyncHandler asyncHandler, ImageCache imageCache) {
        return new MultiImageLoaderInteractorImpl(asyncHandler, imageCache);
    }

    @Provides
    @ChannelsScope
    ChannelsPresenter provideChannelsPresenter(ChannelsDataInteractor channelsDataInteractor,
                                               MultiImageLoaderInteractor imageLoaderInteractor) {
        return new ChannelsPresenterImpl(channelsDataInteractor, imageLoaderInteractor, state);
    }

}
